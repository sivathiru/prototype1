import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';
import Login from '../src/components/authentication/login';
import { BrowserRouter as Router, Route, Link } from 'react-router';

class App extends Component {
  render() {
    return (
      <Router>
      <div className="App">
        <Login />
      </div>
          <div>
            <Route exact path="/" component={Home} />
            <Route exact path="/about" component={About} />
            <Route exact path="/code" component={Code} />
            <Route exact path="/contact" component={Contact} />
            <Route exact path="/presence" component={info} />
          </div>
      </Router>
    );
  }
}

export default App;
