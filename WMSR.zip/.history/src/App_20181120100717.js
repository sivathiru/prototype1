import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import logo from './logo.svg';
import './App.css';
import Login from '../src/components/authentication/login';
import Dashboard from './components/dashboard/dashboard';
import { Router, Route, Link, browserHistory} from 'react-router-dom';
import MainMenu from '../src/Router';

class App extends Component {
  render() {
    return (
      <div>
         <div id="app" className="App">
         <Login />
         <MainMenu />
         <Dashboard />
      </div>
     
   
      </div>
    );
  }
}
ReactDOM.render((
  <Router>
     <Route path = "/" component = {App}>
        {/* <IndexRoute component = {Login} /> */}
        <Route path = "dashboard" component = {Dashboard} />
        <Route path = "login" component = {Login} />
     </Route>
  </Router>
), document.getElementById('app'))
export default App;
