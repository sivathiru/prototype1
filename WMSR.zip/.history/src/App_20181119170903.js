import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';
import Login from '../src/components/authentication/login';
import { BrowserRouter as Router, Route, Link } from 'react-router';

class App extends Component {
  render() {
    return (
      <Router>
      <div className="App">
        <Login />
      </div>
      </Router>
    );
  }
}

export default App;
