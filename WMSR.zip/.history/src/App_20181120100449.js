import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';
import Login from '../src/components/authentication/login';
import Dashboard from './components/dashboard/dashboard';
import { BrowserRouter as Router, Route, Link } from 'react-router-dom';
import MainMenu from '../src/Router';

class App extends Component {
  render() {
    return (
      <div>
         <div id="app" className="App">
         <Login />
         <MainMenu />
         <Dashboard />
      </div>
     
   
      </div>
    );
  }
}

export default App;
