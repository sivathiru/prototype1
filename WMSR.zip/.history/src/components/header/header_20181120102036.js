import React, {Component} from 'react';

class Header extends Component {
    render() {
        return (
           <div>
<div class="col-md-12 mb-3">
    <div class="row header-block">
            <div class="col-md-1 mt-2">
                        <span class="icon-hope></span>
            </div>
            <div class="col-md-3 offset-md-8 mt-1">
                    <div class="col">
                            <div ngbDropdown placement="bottom-right" class="d-inline-block col-md-12">
                                <button class="btn btn-primary-outline pt-0 pb-0" (click)="backToHome()"><i class="fas fa-home mr-1"></i></button>
                              <div class="col-md-7 font-14 p-0" [ngStyle]="{'display':'inline-flex'}">Welcome <span class="ml-2">{{ showLoginUser }}</span></div>
                              <a class="col-md-3 ml-2 dropdown-toggle p-0" id="dropdownBasic1" ngbDropdownToggle> <img src="assets/images/user.png"></a>
                              <div ngbDropdownMenu aria-labelledby="dropdownBasic1">
                                <button class="dropdown-item">Change Password</button>
                                <button class="dropdown-item cursor-pointer float-right" (click)="logoutArticle()">logout</button>
                              </div>
                            </div>
                    </div>
            </div>
    </div>
</div>
           </div>
            );
        }
    }
    
    export default Dashboard;
