import React, {Component} from 'react';
import {UserIcon} from 'assets/images/user.png';

class Header extends Component {
    render() {
        return (
            <div>
                <div className="col-md-12 mb-3">
                    <div className="row header-block">
                        <div className="col-md-1 mt-2">
                            <span
                                className="icon-hope></span>
            </div>
            <div className="
                                col-md-3
                                offset-md-8
                                mt-1">
                                <div className="col">
                                    <div ngbDropdown placement="bottom-right" className="d-inline-block col-md-12">
                                        <button className="btn btn-primary-outline pt-0 pb-0">
                                            <i className="fas fa-home mr-1"></i>
                                        </button>
                                        <div className="col-md-7 font-14 p-0">Welcome
                                            <span className="ml-2">FC_test</span>
                                        </div>
                                        <a
                                            className="col-md-3 ml-2 dropdown-toggle p-0"
                                            id="dropdownBasic1"
                                            ngbDropdownToggle>
                                            <img src={UserIcon}/></a>
                                        <div ngbDropdownMenu aria-labelledby="dropdownBasic1">
                                            <button className="dropdown-item">Change Password</button>
                                            <button className="dropdown-item cursor-pointer float-right">logout</button>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
        );
    }
}

export default Dashboard;
