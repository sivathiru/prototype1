import React, {Component} from 'react';
import {UserIcon} from 'assets/images/user.png';

class Header extends Component {
    render() {
        return (
            <div>
               
            </div> 
        );
    }
}

export default Header;
