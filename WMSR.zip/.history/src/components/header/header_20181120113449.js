import React, { Component } from 'react';
import { UserIcon } from '../../assets/images/user.png';
import { Dropdown, DropdownToggle, DropdownMenu, DropdownItem } from 'reactstrap';

const divStyle = {
    fontSize: '25px'
};
class Header extends Component {
    constructor(props) {
        super(props);
        this.toggle = this.toggle.bind(this);
        this.state = {
            dropdownOpen: false
          };
    }
    toggle(){
        this.setState(prevState => ({
            dropdownOpen: !prevState.dropdownOpen
          }));
    }
    render() {
        return (
            <div>
                <div class="col-md-12 mb-3">
                    <div class="row header-block">
                        <div class="col-md-1 mt-2">

                            <span class="icon-hope" style={divStyle}></span>

                        </div>

                        <div class="col-md-3 offset-md-8 mt-1">
                            <div class="col">
                                <div ngbDropdown placement="bottom-right" class="d-inline-block col-md-12">
                                    <button class="btn btn-primary-outline pt-0 pb-0"><i class="fas fa-home mr-1"></i></button>
                                    <div class="col-md-7 font-14 p-0">Welcome <span class="ml-2">showLoginUser</span></div>
                                    <Dropdown isOpen={this.state.dropdownOpen} toggle={this.toggle}>
                                        <DropdownToggle caret>
                                        <img src={UserIcon} alt="user-icon"/>
        </DropdownToggle>
                                        <DropdownMenu>
                                            <DropdownItem header>Header</DropdownItem>
                                            <DropdownItem disabled>Action</DropdownItem>
                                            <DropdownItem>Another Action</DropdownItem>
                                            <DropdownItem divider />
                                            <DropdownItem>Another Action</DropdownItem>
                                        </DropdownMenu>
                                    </Dropdown>
                                    {/* <a class="col-md-3 ml-2 dropdown-toggle p-0" id="dropdownBasic1" ngbDropdownToggle> <img src={UserIcon} /></a>
                              <div ngbDropdownMenu aria-labelledby="dropdownBasic1">
                                <button class="dropdown-item">Change Password</button>
                                <button class="dropdown-item cursor-pointer float-right">logout</button>
                              </div> */}
                                </div>
                            </div>

                        </div>
                    </div>
                </div>
            </div>

        );
    }
}

export default Header;
