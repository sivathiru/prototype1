import React, {Component} from 'react';
import {UserIcon} from 'assets/images/user.png';

class Header extends Component {
    render() {
        return (
            <div>
               <div class="col-md-12 mb-3">
                    <div class="row header-block">
                    <div class="col-md-1 mt-2">
                   
                        <span class="icon-hope"></span>
                   
                    </div> 
                </div> 
            </div> 
           </div>
        );
    }
}

export default Header;
