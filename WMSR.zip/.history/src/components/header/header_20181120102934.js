import React, {Component} from 'react';
import {UserIcon} from 'assets/images/user.png';

class Header extends Component {
    render() {
        return (
            <div>
               <div class="col-md-12 mb-3">
                    <div class="row header-block">
                    </div> 
                </div> 
            </div> 
        );
    }
}

export default Header;
