import React, { Component } from 'react';

class login extends Component {
    render() {
        return (
            <div>
                
            </div>
        );
    }
}

export default login;