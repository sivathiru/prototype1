import React, { Component } from 'react';

class login extends Component {
    render() {
        return (
            <div>
                test
            </div>
        );
    }
}

export default login;