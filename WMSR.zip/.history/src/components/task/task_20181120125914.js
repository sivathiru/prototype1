import React, {Component} from 'react';

class Task extends Component {
    render() {
        return (
            <div>
                task
            </div>
        )
    }
}