import React, {Component} from 'react';
import Header from '../header/header';

class Task extends Component {
    render() {
        return (
            <div>
                <Header />
                task
            </div>
        )
    }
}

export default Task;