import React, {Component} from 'react';

class Dashboard extends Component {
    render() {
        return (
            );
        }
    }
    
    export default Login;