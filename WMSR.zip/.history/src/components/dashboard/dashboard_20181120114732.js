import React, { Component } from 'react';
import Header from '../header/header';
import { TabContent, TabPane, Nav, NavItem, NavLink, Card, Button, CardTitle, CardText, Row, Col } from 'reactstrap';
import classnames from 'classnames';

class Dashboard extends Component {
    constructor(props) {
        super(props);
        this.toggle = this.toggle.bind(this);
        this.state = {
            activeTab: '1'
          };
    }
    toggle(tab) {
        if (this.state.activeTab !== tab) {
          this.setState({
            activeTab: tab
          });
        }
      }
     
    render() {
        return (
            <div>
                <Header />
                <Nav tabs>
                    <NavItem>
                        <NavLink
                            className={classnames({ active: this.state.activeTab === '1' })}
                            onClick={() => { this.toggle('1'); }}
                        >
                            Journal
            </NavLink>
                    </NavItem>
                    <NavItem>
                        <NavLink
                            className={classnames({ active: this.state.activeTab === '2' })}
                            onClick={() => { this.toggle('2'); }}
                        >
                            GDP
            </NavLink>
                    </NavItem>
                </Nav>
                <TabContent activeTab={this.state.activeTab}>
                    <TabPane tabId="1">
                        <Row>
                            <Col sm="12">
                            <table class="table table-striped table-sm mt-2" [ngStyle]="{'font-size': '12px', 'padding': '2px'}" [mfData]="data" #mf="mfDataTable" [mfRowsOnPage]="5">
                        <thead class="card-text">
                        <tr>
                            <th style="width: 10%">
                                <mfDefaultSorter by="name">Journal</mfDefaultSorter>
                            </th>
                            <th style="width: 10%">
                                <mfDefaultSorter by="email">Artist ID</mfDefaultSorter>
                            </th>
                            <th style="width: 12%">
                                <mfDefaultSorter by="city">Task Name</mfDefaultSorter>
                            </th>
                            <th style="width: 12%">
                                <mfDefaultSorter by="age">Date Assigned</mfDefaultSorter>
                            </th>
                            <th style="width: 12%">
                                <mfDefaultSorter by="city">Due Date</mfDefaultSorter>
                            </th>
                            <th style="width: 12%">
                                <mfDefaultSorter by="city">Date Completed</mfDefaultSorter>
                            </th>
                            <th style="width: 12%">
                                <mfDefaultSorter by="city">Status </mfDefaultSorter>
                            </th>
                            
                            <th style="width: 10%">
                                <mfDefaultSorter by="city">MS Pages</mfDefaultSorter>
                            </th>
                            <th style="width: 10%">
                                <mfDefaultSorter by="city">Action</mfDefaultSorter>
                            </th>
                        </tr>
                        </thead>
                        <tbody>
                        <tr *ngFor="let item of mf.data">
                            <td>{{item.Jcode}}</td>
                            <td>{{item.ARTID}}</td>
                            <td>{{item.Workname}}</td>
                            <td>{{item.Date_Assign | date: 'MMM d, y'}}</td>
                            <td>{{item.Date_Assign | date: 'MMM d, y'}}</td>
                            <td>{{item.Date_Complete | date: 'MMM d, y'}}</td>
                            <td>{{item.ArtStatus}}</td>                            
                            <td>{{item.MSPages}}</td>
                            <td><a (click)="singleArticlePages(item)" target="blank"><i class="fas fa-external-link-alt"></i></a></td>
                        </tr>
                        </tbody>
                        <tfoot>
                        <tr>
                            <td colspan="4">
                                <mfBootstrapPaginator [rowsOnPageSet]="[5,10,25]"></mfBootstrapPaginator>
                            </td>
                        </tr>
                        </tfoot>
                    </table>
                            </Col>
                        </Row>
                    </TabPane>
                    <TabPane tabId="2">
                        <Row>
                            <Col sm="6">
                                <Card body>
                                    <CardTitle>Special Title Treatment</CardTitle>
                                    <CardText>With supporting text below as a natural lead-in to additional content.</CardText>
                                    <Button>Go somewhere</Button>
                                </Card>
                            </Col>
                            <Col sm="6">
                                <Card body>
                                    <CardTitle>Special Title Treatment</CardTitle>
                                    <CardText>With supporting text below as a natural lead-in to additional content.</CardText>
                                    <Button>Go somewhere</Button>
                                </Card>
                            </Col>
                        </Row>
                    </TabPane>
                </TabContent>
            </div>
        );
    }
}

export default Dashboard;