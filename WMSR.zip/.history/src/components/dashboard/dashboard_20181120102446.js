import React, {Component} from 'react';
import Header from '../header/header';

class Dashboard extends Component {
    render() {
        return (
           <div>
            <Header />
                test
           </div>
            );
        }
    }
    
    export default Dashboard;