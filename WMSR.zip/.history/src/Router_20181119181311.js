import React from 'react';
import './App.css';
import Login from '../src/components/authentication/login';
import Dashboard from './components/dashboard/dashboard';
import { BrowserRouter as Router, Route, Link } from 'react-router-dom';
const MainMenu = () => (

<Router>
  <Route path="/" component={Login} />
  {/* <Route path="/dashboard" component={Dashboard} /> */}
  {/* <Route exact path="/code" component={Code} />
  <Route exact path="/contact" component={Contact} />
  <Route exact path="/presence" component={info} /> */}
</Router>

)

export default MainMenu;
