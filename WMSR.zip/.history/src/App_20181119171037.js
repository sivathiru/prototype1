import React, { Component } from 'react';
import logo from './logo.svg';
import './App.css';
import Login from '../src/components/authentication/login';
import Dashboard from './components/dashboard/dashboard';
import { BrowserRouter as Router, Route, Link } from 'react-router';

class App extends Component {
  render() {
    return (
      <Router>
      <div className="App">
        <Login />
      </div>
          <div>
            <Route exact path="/" component={Login} />
            <Route exact path="/dashboard" component={Dashboard} />
            {/* <Route exact path="/code" component={Code} />
            <Route exact path="/contact" component={Contact} />
            <Route exact path="/presence" component={info} /> */}
          </div>
      </Router>
    );
  }
}

export default App;
